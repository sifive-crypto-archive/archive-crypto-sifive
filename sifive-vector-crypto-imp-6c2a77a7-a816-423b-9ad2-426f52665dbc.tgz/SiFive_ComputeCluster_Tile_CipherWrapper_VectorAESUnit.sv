//
// Copyright (c) 2016-2026 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
// Instance ID: 6c2a77a7-a816-423b-9ad2-426f52665dbc, 00000000-0000-0000-0000-000000000000, 00000000-0000-0000-0000-000000000000


// Include register initializers in init blocks unless synthesis is set
`ifndef RANDOMIZE
  `ifdef RANDOMIZE_REG_INIT
    `define RANDOMIZE
  `endif // RANDOMIZE_REG_INIT
`endif // not def RANDOMIZE
`ifndef SYNTHESIS
  `ifndef ENABLE_INITIAL_REG_
    `define ENABLE_INITIAL_REG_
  `endif // not def ENABLE_INITIAL_REG_
`endif // not def SYNTHESIS

// Standard header to adapt well known macros for register randomization.

// RANDOM may be set to an expression that produces a 32-bit random unsigned value.
`ifndef RANDOM
  `define RANDOM $random
`endif // not def RANDOM

// Users can define INIT_RANDOM as general code that gets injected into the
// initializer block for modules with registers.
`ifndef INIT_RANDOM
  `define INIT_RANDOM
`endif // not def INIT_RANDOM

// If using random initialization, you can also define RANDOMIZE_DELAY to
// customize the delay used, otherwise 0.002 is used.
`ifndef RANDOMIZE_DELAY
  `define RANDOMIZE_DELAY 0.002
`endif // not def RANDOMIZE_DELAY

// Define INIT_RANDOM_PROLOG_ for use in our modules below.
`ifndef INIT_RANDOM_PROLOG_
  `ifdef RANDOMIZE
    `ifdef VERILATOR
      `define INIT_RANDOM_PROLOG_ `INIT_RANDOM
    `else  // VERILATOR
      `define INIT_RANDOM_PROLOG_ `INIT_RANDOM #`RANDOMIZE_DELAY begin end
    `endif // VERILATOR
  `else  // RANDOMIZE
    `define INIT_RANDOM_PROLOG_
  `endif // RANDOMIZE
`endif // not def INIT_RANDOM_PROLOG_
module SiFive_ComputeCluster_Tile_CipherWrapper_VectorAESUnit(
  input          clock,
  input          reset,
  input          io_cmd_valid,
  input          io_cmd_bits_uop_vaesem,
  input          io_cmd_bits_uop_vaesef,
  input          io_cmd_bits_uop_vaesdm,
  input          io_cmd_bits_uop_vaesdf,
  input          io_cmd_bits_uop_vaeskf1,
  input          io_cmd_bits_uop_vaeskf2,
  input  [3:0]   io_cmd_bits_roundGrp,
  input  [127:0] io_dataIn_1,
  input  [127:0] io_dataIn_2,
  output         io_dataOut_0_valid,
  output [127:0] io_dataOut_0_bits
);

  wire         _GEN_27 = io_cmd_bits_uop_vaesem;
  wire [127:0] _GEN_24 = io_dataIn_1;
  wire [127:0] _GEN_20 = io_dataIn_1;
  wire [127:0] _GEN_17 = io_dataIn_2;
  wire [127:0] _GEN_15 = io_dataIn_2;
  wire [127:0] _GEN_14 = io_dataIn_2;
  wire [127:0] _GEN_13 = io_dataIn_1;
  wire [127:0] _GEN_11 = io_dataIn_1;
  wire         _GEN_2 = io_cmd_bits_uop_vaesdm;
  reg          _GEN_19;
  reg  [127:0] _GEN_1;
  wire [3:0]   _GEN_7 = {(|io_cmd_bits_roundGrp) & io_cmd_bits_roundGrp < 4'hB ^ ~(io_cmd_bits_roundGrp[3]), io_cmd_bits_roundGrp[2:0]};
  wire [3:0]   _GEN_3 = {(|(io_cmd_bits_roundGrp[3:1])) & io_cmd_bits_roundGrp != 4'hF ^ ~(io_cmd_bits_roundGrp[3]), io_cmd_bits_roundGrp[2:0]};
  wire         _GEN_22 = io_cmd_valid & (io_cmd_bits_uop_vaesem | io_cmd_bits_uop_vaesef);
  wire         _GEN_6 = io_cmd_valid & (io_cmd_bits_uop_vaesdm | io_cmd_bits_uop_vaesdf);
  wire         _GEN_21 = io_cmd_valid & io_cmd_bits_uop_vaeskf1;
  wire         _GEN_0 = io_cmd_valid & io_cmd_bits_uop_vaeskf2;
  wire [127:0] _GEN_4;
  wire [127:0] _GEN = _GEN_22 ? _GEN_4 : 128'h0;
  wire [127:0] _GEN_23;
  wire [127:0] _GEN_5 = _GEN_6 ? _GEN_23 : _GEN;
  wire [127:0] _GEN_5_0;
  wire [127:0] _GEN_8 = _GEN_21 ? _GEN_5_0 : _GEN_5;
  wire [127:0] _GEN_10;
  wire         _GEN_9 = _GEN_0 | _GEN_21 | _GEN_6 | _GEN_22;
  always @(posedge clock) begin
    if (reset)
      _GEN_19 <= 1'h0;
    else
      _GEN_19 <= _GEN_9;
    if (_GEN_9)
      _GEN_1 <= _GEN_0 ? _GEN_10 : _GEN_8;
  end // always @(posedge)
  `ifdef ENABLE_INITIAL_REG_
    `ifdef FIRRTL_BEFORE_INITIAL
      `FIRRTL_BEFORE_INITIAL
    `endif // FIRRTL_BEFORE_INITIAL
    logic [31:0] _GEN_16[0:4];
    initial begin
      `ifdef INIT_RANDOM_PROLOG_
        `INIT_RANDOM_PROLOG_
      `endif // INIT_RANDOM_PROLOG_
      `ifdef RANDOMIZE_REG_INIT
        for (logic [2:0] i = 3'h0; i < 3'h5; i += 3'h1) begin
          _GEN_16[i] = `RANDOM;
        end
        _GEN_19 = _GEN_16[3'h0][0];
        _GEN_1 = {_GEN_16[3'h0][31:1], _GEN_16[3'h1], _GEN_16[3'h2], _GEN_16[3'h3], _GEN_16[3'h4][0]};
      `endif // RANDOMIZE_REG_INIT
    end // initial
    `ifdef FIRRTL_AFTER_INITIAL
      `FIRRTL_AFTER_INITIAL
    `endif // FIRRTL_AFTER_INITIAL
  `endif // ENABLE_INITIAL_REG_
  SiFive_ComputeCluster_Tile_CipherWrapper_CipherInternal_AES128FwdKeySch aes128FwdKeySch (
    .io_curRndKey  (_GEN_24),
    .io_nextRndKey (_GEN_5_0),
    .io_rndNumber  (_GEN_7)
  );
  SiFive_ComputeCluster_Tile_CipherWrapper_CipherInternal_AESDecRnd aesDecRnd (
    .io_roundIn     (_GEN_17),
    .io_roundKey    (_GEN_13),
    .io_roundOut    (_GEN_23),
    .io_isMiddleRnd (_GEN_2)
  );
  SiFive_ComputeCluster_Tile_CipherWrapper_CipherInternal_AESEncRnd aesEncRnd (
    .io_roundIn     (_GEN_15),
    .io_roundKey    (_GEN_20),
    .io_roundOut    (_GEN_4),
    .io_isMiddleRnd (_GEN_27)
  );
  SiFive_ComputeCluster_Tile_CipherWrapper_CipherInternal_AES256FwdKeySch aes256FwdKeySch (
    .io_prevRndKey (_GEN_14),
    .io_curRndKey  (_GEN_11),
    .io_nextRndKey (_GEN_10),
    .io_rndNumber  (_GEN_3)
  );
  assign io_dataOut_0_valid = _GEN_19;
  assign io_dataOut_0_bits = _GEN_1;
endmodule

