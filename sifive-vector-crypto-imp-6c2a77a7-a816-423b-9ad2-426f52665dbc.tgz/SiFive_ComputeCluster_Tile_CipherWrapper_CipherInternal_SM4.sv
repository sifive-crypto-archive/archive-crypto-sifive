//
// Copyright (c) 2016-2026 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
// Instance ID: 6c2a77a7-a816-423b-9ad2-426f52665dbc, 00000000-0000-0000-0000-000000000000, 00000000-0000-0000-0000-000000000000

module SiFive_ComputeCluster_Tile_CipherWrapper_CipherInternal_SM4(
  input  [127:0] io_rksIn,
  input  [127:0] io_xsIn,
  input  [2:0]   io_rnd,
  input          io_isKE,
  output [127:0] io_rksOrXsOut
);

  wire [7:0][31:0] _GEN = '{32'h646B7279, 32'hF4FB0209, 32'h848B9299, 32'h141B2229, 32'hA4ABB2B9, 32'h343B4249, 32'hC4CBD2D9, 32'h545B6269};
  wire [7:0][31:0] _GEN_0 = '{32'h484F565D, 32'hD8DFE6ED, 32'h686F767D, 32'hF8FF060D, 32'h888F969D, 32'h181F262D, 32'hA8AFB6BD, 32'h383F464D};
  wire [7:0][31:0] _GEN_1 = '{32'h2C333A41, 32'hBCC3CAD1, 32'h4C535A61, 32'hDCE3EAF1, 32'h6C737A81, 32'hFC030A11, 32'h8C939AA1, 32'h1C232A31};
  wire [7:0][31:0] _GEN_2 = '{32'h10171E25, 32'hA0A7AEB5, 32'h30373E45, 32'hC0C7CED5, 32'h50575E65, 32'hE0E7EEF5, 32'h70777E85, 32'h70E15};
  wire [31:0]      _GEN_17 = io_rksIn[63:32] ^ io_rksIn[95:64] ^ io_rksIn[127:96] ^ _GEN_2[io_rnd];
  wire [31:0]      _GEN_16;
  wire [31:0]      _GEN_8 = io_xsIn[63:32] ^ io_xsIn[95:64] ^ io_xsIn[127:96] ^ io_rksIn[31:0];
  wire [31:0]      _GEN_3 = io_rksIn[31:0] ^ _GEN_16 ^ {_GEN_16[18:0], _GEN_16[31:19]} ^ {_GEN_16[8:0], _GEN_16[31:9]};
  wire [31:0]      _GEN_7;
  wire [31:0]      _GEN_4 =
    io_xsIn[31:0] ^ _GEN_7 ^ {_GEN_7[29:0], _GEN_7[31:30]} ^ {_GEN_7[21:0], _GEN_7[31:22]} ^ {_GEN_7[13:0], _GEN_7[31:14]} ^ {_GEN_7[7:0], _GEN_7[31:8]};
  wire [31:0]      _GEN_3_0 = io_rksIn[95:64] ^ io_rksIn[127:96] ^ _GEN_3 ^ _GEN_1[io_rnd];
  wire [31:0]      _GEN_6 = io_xsIn[95:64] ^ io_xsIn[127:96] ^ _GEN_4 ^ io_rksIn[63:32];
  wire [31:0]      _GEN_0_0;
  wire [31:0]      _GEN_5 = io_rksIn[63:32] ^ _GEN_0_0 ^ {_GEN_0_0[18:0], _GEN_0_0[31:19]} ^ {_GEN_0_0[8:0], _GEN_0_0[31:9]};
  wire [31:0]      _GEN_15;
  wire [31:0]      _GEN_9 =
    io_xsIn[63:32] ^ _GEN_15 ^ {_GEN_15[29:0], _GEN_15[31:30]} ^ {_GEN_15[21:0], _GEN_15[31:22]} ^ {_GEN_15[13:0], _GEN_15[31:14]}
    ^ {_GEN_15[7:0], _GEN_15[31:8]};
  wire [31:0]      _GEN_10 = {32{io_isKE}};
  wire [31:0]      _GEN_11 = (_GEN_10 & io_rksIn[127:96] | {32{~io_isKE}} & io_xsIn[127:96]) ^ (_GEN_10 & _GEN_3 | {32{~io_isKE}} & _GEN_4);
  wire [31:0]      _GEN_12 = (_GEN_10 & _GEN_5 | {32{~io_isKE}} & _GEN_9) ^ (_GEN_10 & _GEN_0[io_rnd] | {32{~io_isKE}} & io_rksIn[95:64]);
  wire [31:0]      _GEN_14 = _GEN_11 ^ _GEN_12;
  wire [31:0]      _GEN_10_0;
  wire [31:0]      _GEN_13 = io_rksIn[95:64] ^ _GEN_10_0 ^ {_GEN_10_0[18:0], _GEN_10_0[31:19]} ^ {_GEN_10_0[8:0], _GEN_10_0[31:9]};
  wire [31:0]      _GEN_18 =
    io_xsIn[95:64] ^ _GEN_10_0 ^ {_GEN_10_0[29:0], _GEN_10_0[31:30]} ^ {_GEN_10_0[21:0], _GEN_10_0[31:22]} ^ {_GEN_10_0[13:0], _GEN_10_0[31:14]}
    ^ {_GEN_10_0[7:0], _GEN_10_0[31:8]};
  wire [31:0]      _GEN_19 = (_GEN_10 & _GEN_3 | {32{~io_isKE}} & _GEN_4) ^ (_GEN_10 & _GEN_5 | {32{~io_isKE}} & _GEN_9);
  wire [31:0]      _GEN_20 = (_GEN_10 & _GEN_13 | {32{~io_isKE}} & _GEN_18) ^ (_GEN_10 & _GEN[io_rnd] | {32{~io_isKE}} & io_rksIn[127:96]);
  wire [31:0]      _GEN_5_0 = _GEN_19 ^ _GEN_20;
  wire [31:0]      _GEN_1_0;
  wire [31:0]      _GEN_21 =
    io_xsIn[127:96] ^ _GEN_1_0 ^ {_GEN_1_0[29:0], _GEN_1_0[31:30]} ^ {_GEN_1_0[21:0], _GEN_1_0[31:22]} ^ {_GEN_1_0[13:0], _GEN_1_0[31:14]}
    ^ {_GEN_1_0[7:0], _GEN_1_0[31:8]};
  wire [31:0]      _GEN_22 =
    _GEN_10 & (io_rksIn[127:96] ^ _GEN_1_0 ^ {_GEN_1_0[18:0], _GEN_1_0[31:19]} ^ {_GEN_1_0[8:0], _GEN_1_0[31:9]}) | {32{~io_isKE}} & _GEN_21;
  SiFive_ComputeCluster_Tile_CipherWrapper_CipherInternal_CipherInternal_SM4SBoxLUT round_7_S2_sBoxRes_sBoxLUT (
    .io_in  (_GEN_5_0),
    .io_out (_GEN_1_0)
  );
  SiFive_ComputeCluster_Tile_CipherWrapper_CipherInternal_CipherInternal_SM4SBoxLUT round_4_sBoxLUT (
    .io_in  (_GEN_17),
    .io_out (_GEN_16)
  );
  SiFive_ComputeCluster_Tile_CipherWrapper_CipherInternal_CipherInternal_SM4SBoxLUT round_4_sBoxLUT_1 (
    .io_in  (_GEN_8),
    .io_out (_GEN_7)
  );
  SiFive_ComputeCluster_Tile_CipherWrapper_CipherInternal_CipherInternal_SM4SBoxLUT round_5_sBoxLUT_1 (
    .io_in  (_GEN_6),
    .io_out (_GEN_15)
  );
  SiFive_ComputeCluster_Tile_CipherWrapper_CipherInternal_CipherInternal_SM4SBoxLUT round_5_sBoxLUT (
    .io_in  (_GEN_3_0),
    .io_out (_GEN_0_0)
  );
  SiFive_ComputeCluster_Tile_CipherWrapper_CipherInternal_CipherInternal_SM4SBoxLUT round_6_S1_sBoxRes_sBoxLUT (
    .io_in  (_GEN_14),
    .io_out (_GEN_10_0)
  );
  assign io_rksOrXsOut =
    {_GEN_22, _GEN_10 & _GEN_13 | {32{~io_isKE}} & _GEN_18, _GEN_10 & _GEN_5 | {32{~io_isKE}} & _GEN_9, _GEN_10 & _GEN_3 | {32{~io_isKE}} & _GEN_4};
endmodule

