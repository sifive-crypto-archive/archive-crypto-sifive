//
// Copyright (c) 2016-2026 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
// Instance ID: 6c2a77a7-a816-423b-9ad2-426f52665dbc, 00000000-0000-0000-0000-000000000000, 00000000-0000-0000-0000-000000000000


// Include register initializers in init blocks unless synthesis is set
`ifndef RANDOMIZE
  `ifdef RANDOMIZE_REG_INIT
    `define RANDOMIZE
  `endif // RANDOMIZE_REG_INIT
`endif // not def RANDOMIZE
`ifndef SYNTHESIS
  `ifndef ENABLE_INITIAL_REG_
    `define ENABLE_INITIAL_REG_
  `endif // not def ENABLE_INITIAL_REG_
`endif // not def SYNTHESIS

// Standard header to adapt well known macros for register randomization.

// RANDOM may be set to an expression that produces a 32-bit random unsigned value.
`ifndef RANDOM
  `define RANDOM $random
`endif // not def RANDOM

// Users can define INIT_RANDOM as general code that gets injected into the
// initializer block for modules with registers.
`ifndef INIT_RANDOM
  `define INIT_RANDOM
`endif // not def INIT_RANDOM

// If using random initialization, you can also define RANDOMIZE_DELAY to
// customize the delay used, otherwise 0.002 is used.
`ifndef RANDOMIZE_DELAY
  `define RANDOMIZE_DELAY 0.002
`endif // not def RANDOMIZE_DELAY

// Define INIT_RANDOM_PROLOG_ for use in our modules below.
`ifndef INIT_RANDOM_PROLOG_
  `ifdef RANDOMIZE
    `ifdef VERILATOR
      `define INIT_RANDOM_PROLOG_ `INIT_RANDOM
    `else  // VERILATOR
      `define INIT_RANDOM_PROLOG_ `INIT_RANDOM #`RANDOMIZE_DELAY begin end
    `endif // VERILATOR
  `else  // RANDOMIZE
    `define INIT_RANDOM_PROLOG_
  `endif // RANDOMIZE
`endif // not def INIT_RANDOM_PROLOG_
module SiFive_ComputeCluster_Tile_CipherWrapper_VectorSM4UnitRetimed(
  input          clock,
  input          reset,
  input          io_cmd_valid,
  input          io_cmd_bits_uop_vsm4k,
  input          io_cmd_bits_uop_vsm4r,
  input  [3:0]   io_cmd_bits_roundGrp,
  input  [127:0] io_dataIn_1,
  input  [127:0] io_dataIn_2,
  output         io_dataOut_0_valid,
  output [127:0] io_dataOut_0_bits
);

  wire [127:0] _GEN_6 = io_dataIn_2;
  wire [127:0] _GEN_5 = io_dataIn_1;
  wire         _GEN_4 = io_cmd_bits_uop_vsm4k;
  reg          _GEN_10;
  reg          _GEN_9;
  reg          _GEN_8;
  reg  [127:0] _GEN_7;
  reg  [127:0] _GEN_3;
  reg  [127:0] _GEN_2;
  wire [2:0]   _GEN_11 = io_cmd_bits_roundGrp[2:0];
  wire         _GEN = io_cmd_valid & (io_cmd_bits_uop_vsm4k | io_cmd_bits_uop_vsm4r);
  wire [127:0] _GEN_12;
  always @(posedge clock) begin
    if (reset) begin
      _GEN_10 <= 1'h0;
      _GEN_8 <= 1'h0;
      _GEN_9 <= 1'h0;
    end
    else begin
      _GEN_10 <= _GEN;
      _GEN_8 <= _GEN_10;
      _GEN_9 <= _GEN_8;
    end
    if (_GEN)
      _GEN_3 <= _GEN_12;
    if (_GEN_10)
      _GEN_7 <= _GEN_3;
    if (_GEN_8)
      _GEN_2 <= _GEN_7;
  end // always @(posedge)
  `ifdef ENABLE_INITIAL_REG_
    `ifdef FIRRTL_BEFORE_INITIAL
      `FIRRTL_BEFORE_INITIAL
    `endif // FIRRTL_BEFORE_INITIAL
    logic [31:0] _GEN_1[0:12];
    initial begin
      `ifdef INIT_RANDOM_PROLOG_
        `INIT_RANDOM_PROLOG_
      `endif // INIT_RANDOM_PROLOG_
      `ifdef RANDOMIZE_REG_INIT
        for (logic [3:0] i = 4'h0; i < 4'hD; i += 4'h1) begin
          _GEN_1[i] = `RANDOM;
        end
        _GEN_10 = _GEN_1[4'h0][0];
        _GEN_3 = {_GEN_1[4'h0][31:1], _GEN_1[4'h1], _GEN_1[4'h2], _GEN_1[4'h3], _GEN_1[4'h4][0]};
        _GEN_8 = _GEN_1[4'h4][1];
        _GEN_7 = {_GEN_1[4'h4][31:2], _GEN_1[4'h5], _GEN_1[4'h6], _GEN_1[4'h7], _GEN_1[4'h8][1:0]};
        _GEN_9 = _GEN_1[4'h8][2];
        _GEN_2 = {_GEN_1[4'h8][31:3], _GEN_1[4'h9], _GEN_1[4'hA], _GEN_1[4'hB], _GEN_1[4'hC][2:0]};
      `endif // RANDOMIZE_REG_INIT
    end // initial
    `ifdef FIRRTL_AFTER_INITIAL
      `FIRRTL_AFTER_INITIAL
    `endif // FIRRTL_AFTER_INITIAL
  `endif // ENABLE_INITIAL_REG_
  SiFive_ComputeCluster_Tile_CipherWrapper_CipherInternal_SM4 sm4Out_vdOuts_sm4 (
    .io_rksIn      (_GEN_5),
    .io_xsIn       (_GEN_6),
    .io_rnd        (_GEN_11),
    .io_isKE       (_GEN_4),
    .io_rksOrXsOut (_GEN_12)
  );
  assign io_dataOut_0_valid = _GEN_9;
  assign io_dataOut_0_bits = _GEN_2;
endmodule

