//
// Copyright (c) 2016-2026 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
// Instance ID: 461ff9eb-9411-4425-bb90-2ea6b7460bef, 00000000-0000-0000-0000-000000000000, 00000000-0000-0000-0000-000000000000


// Include register initializers in init blocks unless synthesis is set
`ifndef RANDOMIZE
  `ifdef RANDOMIZE_REG_INIT
    `define RANDOMIZE
  `endif // RANDOMIZE_REG_INIT
`endif // not def RANDOMIZE
`ifndef SYNTHESIS
  `ifndef ENABLE_INITIAL_REG_
    `define ENABLE_INITIAL_REG_
  `endif // not def ENABLE_INITIAL_REG_
`endif // not def SYNTHESIS

// Standard header to adapt well known macros for register randomization.

// RANDOM may be set to an expression that produces a 32-bit random unsigned value.
`ifndef RANDOM
  `define RANDOM $random
`endif // not def RANDOM

// Users can define INIT_RANDOM as general code that gets injected into the
// initializer block for modules with registers.
`ifndef INIT_RANDOM
  `define INIT_RANDOM
`endif // not def INIT_RANDOM

// If using random initialization, you can also define RANDOMIZE_DELAY to
// customize the delay used, otherwise 0.002 is used.
`ifndef RANDOMIZE_DELAY
  `define RANDOMIZE_DELAY 0.002
`endif // not def RANDOMIZE_DELAY

// Define INIT_RANDOM_PROLOG_ for use in our modules below.
`ifndef INIT_RANDOM_PROLOG_
  `ifdef RANDOMIZE
    `ifdef VERILATOR
      `define INIT_RANDOM_PROLOG_ `INIT_RANDOM
    `else  // VERILATOR
      `define INIT_RANDOM_PROLOG_ `INIT_RANDOM #`RANDOMIZE_DELAY begin end
    `endif // VERILATOR
  `else  // RANDOMIZE
    `define INIT_RANDOM_PROLOG_
  `endif // RANDOMIZE
`endif // not def INIT_RANDOM_PROLOG_
module SiFive_ComputeCluster_Tile_CipherWrapper_CipherInternal_SM4(
  input          clock,
  input          io_valid,
  input  [127:0] io_rksIn,
  input  [127:0] io_xsIn,
  input  [2:0]   io_rnd,
  input          io_isKE,
  output [127:0] io_rksOrXsOut
);

  reg  [31:0]      _GEN_42;
  reg  [2:0]       _GEN_41;
  reg  [31:0]      _GEN_40;
  reg  [31:0]      _GEN_39;
  reg              _GEN_38;
  reg  [31:0]      _GEN_36;
  reg  [31:0]      _GEN_32;
  reg  [31:0]      _GEN_30;
  reg  [31:0]      _GEN_29;
  reg  [31:0]      _GEN_26;
  reg  [31:0]      _GEN_22;
  reg  [31:0]      _GEN_21;
  reg              _GEN_20;
  reg  [31:0]      _GEN_18;
  reg  [31:0]      _GEN_17;
  reg  [31:0]      _GEN_15;
  reg  [31:0]      _GEN_14;
  reg  [31:0]      _GEN_13;
  reg  [31:0]      _GEN_12;
  reg  [31:0]      _GEN_11;
  reg              _GEN_9;
  reg  [31:0]      _GEN_4;
  reg  [31:0]      _GEN_2;
  reg  [31:0]      _GEN_1;
  reg  [31:0]      _GEN_0;
  wire [7:0][31:0] _GEN = '{32'h484F565D, 32'hD8DFE6ED, 32'h686F767D, 32'hF8FF060D, 32'h888F969D, 32'h181F262D, 32'hA8AFB6BD, 32'h383F464D};
  wire [7:0][31:0] _GEN_3 = '{32'h2C333A41, 32'hBCC3CAD1, 32'h4C535A61, 32'hDCE3EAF1, 32'h6C737A81, 32'hFC030A11, 32'h8C939AA1, 32'h1C232A31};
  wire [7:0][31:0] _GEN_5 = '{32'h10171E25, 32'hA0A7AEB5, 32'h30373E45, 32'hC0C7CED5, 32'h50575E65, 32'hE0E7EEF5, 32'h70777E85, 32'h70E15};
  wire [31:0]      _GEN_25 = io_rksIn[63:32] ^ io_rksIn[95:64] ^ io_rksIn[127:96] ^ _GEN_5[io_rnd];
  wire [31:0]      _GEN_23 = io_xsIn[63:32] ^ io_xsIn[95:64] ^ io_xsIn[127:96] ^ io_rksIn[31:0];
  wire [31:0]      _GEN_3_0;
  wire [31:0]      _GEN_6 = io_rksIn[31:0] ^ _GEN_3_0 ^ {_GEN_3_0[18:0], _GEN_3_0[31:19]} ^ {_GEN_3_0[8:0], _GEN_3_0[31:9]};
  wire [31:0]      _GEN_28;
  wire [31:0]      _GEN_7 =
    io_xsIn[31:0] ^ _GEN_28 ^ {_GEN_28[29:0], _GEN_28[31:30]} ^ {_GEN_28[21:0], _GEN_28[31:22]} ^ {_GEN_28[13:0], _GEN_28[31:14]}
    ^ {_GEN_28[7:0], _GEN_28[31:8]};
  wire [31:0]      _GEN_35 = io_rksIn[95:64] ^ io_rksIn[127:96] ^ _GEN_6 ^ _GEN_3[io_rnd];
  wire [31:0]      _GEN_34 = io_xsIn[95:64] ^ io_xsIn[127:96] ^ _GEN_7 ^ io_rksIn[63:32];
  wire [31:0]      _GEN_8 = {32{_GEN_38}};
  wire [31:0]      _GEN_10 = (_GEN_8 & _GEN_40 | {32{~_GEN_38}} & _GEN_1) ^ (_GEN_8 & _GEN_22 | {32{~_GEN_38}} & _GEN_29);
  wire [31:0]      _GEN_16 = (_GEN_8 & _GEN_42 | {32{~_GEN_38}} & _GEN_32) ^ (_GEN_8 & _GEN[_GEN_41] | {32{~_GEN_38}} & _GEN_21);
  wire [31:0]      _GEN_27 = _GEN_10 ^ _GEN_16;
  wire [31:0]      _GEN_5_0;
  wire [31:0]      _GEN_19 =
    _GEN_39 ^ _GEN_5_0 ^ {_GEN_5_0[29:0], _GEN_5_0[31:30]} ^ {_GEN_5_0[21:0], _GEN_5_0[31:22]} ^ {_GEN_5_0[13:0], _GEN_5_0[31:14]}
    ^ {_GEN_5_0[7:0], _GEN_5_0[31:8]};
  wire [31:0]      _GEN_24 = {32{_GEN_9}};
  wire [31:0]      _GEN_31 = _GEN_24 & (_GEN_36 ^ _GEN_5_0 ^ {_GEN_5_0[18:0], _GEN_5_0[31:19]} ^ {_GEN_5_0[8:0], _GEN_5_0[31:9]}) | {32{~_GEN_9}} & _GEN_19;
  wire [31:0]      _GEN_10_0;
  wire [31:0]      _GEN_33 = io_rksIn[63:32] ^ _GEN_10_0 ^ {_GEN_10_0[18:0], _GEN_10_0[31:19]} ^ {_GEN_10_0[8:0], _GEN_10_0[31:9]};
  wire [31:0]      _GEN_31_0;
  wire [31:0]      _GEN_37 =
    io_xsIn[63:32] ^ _GEN_31_0 ^ {_GEN_31_0[29:0], _GEN_31_0[31:30]} ^ {_GEN_31_0[21:0], _GEN_31_0[31:22]} ^ {_GEN_31_0[13:0], _GEN_31_0[31:14]}
    ^ {_GEN_31_0[7:0], _GEN_31_0[31:8]};
  wire [7:0][31:0] _GEN_43 = '{32'h646B7279, 32'hF4FB0209, 32'h848B9299, 32'h141B2229, 32'hA4ABB2B9, 32'h343B4249, 32'hC4CBD2D9, 32'h545B6269};
  wire [31:0]      _GEN_37_0;
  wire [31:0]      _GEN_44 = _GEN_21 ^ _GEN_37_0 ^ {_GEN_37_0[18:0], _GEN_37_0[31:19]} ^ {_GEN_37_0[8:0], _GEN_37_0[31:9]};
  wire [31:0]      _GEN_45 =
    _GEN_12 ^ _GEN_37_0 ^ {_GEN_37_0[29:0], _GEN_37_0[31:30]} ^ {_GEN_37_0[21:0], _GEN_37_0[31:22]} ^ {_GEN_37_0[13:0], _GEN_37_0[31:14]}
    ^ {_GEN_37_0[7:0], _GEN_37_0[31:8]};
  wire [31:0]      _GEN_46 = (_GEN_8 & _GEN_22 | {32{~_GEN_38}} & _GEN_29) ^ (_GEN_8 & _GEN_42 | {32{~_GEN_38}} & _GEN_32);
  wire [31:0]      _GEN_47 = (_GEN_8 & _GEN_44 | {32{~_GEN_38}} & _GEN_45) ^ (_GEN_8 & _GEN_43[_GEN_41] | {32{~_GEN_38}} & _GEN_40);
  always @(posedge clock) begin
    _GEN_20 <= io_valid;
    if (io_valid) begin
      _GEN_41 <= io_rnd;
      _GEN_38 <= io_isKE;
      _GEN_30 <= _GEN_6;
      _GEN_26 <= _GEN_7;
      _GEN_0 <= _GEN_33;
      _GEN_17 <= _GEN_37;
      _GEN_21 <= io_rksIn[95:64];
      _GEN_40 <= io_rksIn[127:96];
      _GEN_22 <= _GEN_6;
      _GEN_42 <= _GEN_33;
      _GEN_12 <= io_xsIn[95:64];
      _GEN_1 <= io_xsIn[127:96];
      _GEN_29 <= _GEN_7;
      _GEN_32 <= _GEN_37;
    end
    if (_GEN_20) begin
      _GEN_9 <= _GEN_38;
      _GEN_15 <= _GEN_30;
      _GEN_14 <= _GEN_26;
      _GEN_11 <= _GEN_0;
      _GEN_4 <= _GEN_17;
      _GEN_18 <= _GEN_44;
      _GEN_2 <= _GEN_45;
      _GEN_13 <= _GEN_46 ^ _GEN_47;
      _GEN_36 <= _GEN_40;
      _GEN_39 <= _GEN_1;
    end
  end // always @(posedge)
  `ifdef ENABLE_INITIAL_REG_
    `ifdef FIRRTL_BEFORE_INITIAL
      `FIRRTL_BEFORE_INITIAL
    `endif // FIRRTL_BEFORE_INITIAL
    logic [31:0] _GEN_33_0[0:53];
    initial begin
      `ifdef INIT_RANDOM_PROLOG_
        `INIT_RANDOM_PROLOG_
      `endif // INIT_RANDOM_PROLOG_
      `ifdef RANDOMIZE_REG_INIT
        for (logic [5:0] i = 6'h0; i < 6'h36; i += 6'h1) begin
          _GEN_33_0[i] = `RANDOM;
        end
        _GEN_20 = _GEN_33_0[6'h0][0];
        _GEN_41 = _GEN_33_0[6'h0][3:1];
        _GEN_38 = _GEN_33_0[6'h0][4];
        _GEN_30 = {_GEN_33_0[6'h0][31:5], _GEN_33_0[6'h1][4:0]};
        _GEN_26 = {_GEN_33_0[6'h1][31:5], _GEN_33_0[6'h2][4:0]};
        _GEN_0 = {_GEN_33_0[6'hA][31:5], _GEN_33_0[6'hB][4:0]};
        _GEN_17 = {_GEN_33_0[6'hB][31:5], _GEN_33_0[6'hC][4:0]};
        _GEN_21 = {_GEN_33_0[6'hC][31:5], _GEN_33_0[6'hD][4:0]};
        _GEN_40 = {_GEN_33_0[6'hD][31:5], _GEN_33_0[6'hE][4:0]};
        _GEN_22 = {_GEN_33_0[6'hE][31:5], _GEN_33_0[6'hF][4:0]};
        _GEN_42 = {_GEN_33_0[6'hF][31:5], _GEN_33_0[6'h10][4:0]};
        _GEN_12 = {_GEN_33_0[6'h10][31:5], _GEN_33_0[6'h11][4:0]};
        _GEN_1 = {_GEN_33_0[6'h11][31:5], _GEN_33_0[6'h12][4:0]};
        _GEN_29 = {_GEN_33_0[6'h12][31:5], _GEN_33_0[6'h13][4:0]};
        _GEN_32 = {_GEN_33_0[6'h13][31:5], _GEN_33_0[6'h14][4:0]};
        _GEN_9 = _GEN_33_0[6'h14][5];
        _GEN_15 = {_GEN_33_0[6'h14][31:6], _GEN_33_0[6'h15][5:0]};
        _GEN_14 = {_GEN_33_0[6'h15][31:6], _GEN_33_0[6'h16][5:0]};
        _GEN_11 = {_GEN_33_0[6'h1E][31:6], _GEN_33_0[6'h1F][5:0]};
        _GEN_4 = {_GEN_33_0[6'h1F][31:6], _GEN_33_0[6'h20][5:0]};
        _GEN_18 = {_GEN_33_0[6'h28][31:6], _GEN_33_0[6'h29][5:0]};
        _GEN_2 = {_GEN_33_0[6'h29][31:6], _GEN_33_0[6'h2A][5:0]};
        _GEN_13 = {_GEN_33_0[6'h32][31:6], _GEN_33_0[6'h33][5:0]};
        _GEN_36 = {_GEN_33_0[6'h33][31:6], _GEN_33_0[6'h34][5:0]};
        _GEN_39 = {_GEN_33_0[6'h34][31:6], _GEN_33_0[6'h35][5:0]};
      `endif // RANDOMIZE_REG_INIT
    end // initial
    `ifdef FIRRTL_AFTER_INITIAL
      `FIRRTL_AFTER_INITIAL
    `endif // FIRRTL_AFTER_INITIAL
  `endif // ENABLE_INITIAL_REG_
  SiFive_ComputeCluster_Tile_CipherWrapper_CipherInternal_CipherInternal_SM4SBoxLUT round_4_sBoxLUT_1 (
    .io_in  (_GEN_23),
    .io_out (_GEN_28)
  );
  SiFive_ComputeCluster_Tile_CipherWrapper_CipherInternal_CipherInternal_SM4SBoxLUT round_6_S1_sBoxRes_sBoxLUT (
    .io_in  (_GEN_27),
    .io_out (_GEN_37_0)
  );
  SiFive_ComputeCluster_Tile_CipherWrapper_CipherInternal_CipherInternal_SM4SBoxLUT round_4_sBoxLUT (
    .io_in  (_GEN_25),
    .io_out (_GEN_3_0)
  );
  SiFive_ComputeCluster_Tile_CipherWrapper_CipherInternal_CipherInternal_SM4SBoxLUT round_5_sBoxLUT (
    .io_in  (_GEN_35),
    .io_out (_GEN_10_0)
  );
  SiFive_ComputeCluster_Tile_CipherWrapper_CipherInternal_CipherInternal_SM4SBoxLUT round_7_S2_sBoxRes_sBoxLUT (
    .io_in  (_GEN_13),
    .io_out (_GEN_5_0)
  );
  SiFive_ComputeCluster_Tile_CipherWrapper_CipherInternal_CipherInternal_SM4SBoxLUT round_5_sBoxLUT_1 (
    .io_in  (_GEN_34),
    .io_out (_GEN_31_0)
  );
  assign io_rksOrXsOut =
    {_GEN_31, _GEN_24 & _GEN_18 | {32{~_GEN_9}} & _GEN_2, _GEN_24 & _GEN_11 | {32{~_GEN_9}} & _GEN_4, _GEN_24 & _GEN_15 | {32{~_GEN_9}} & _GEN_14};
endmodule

