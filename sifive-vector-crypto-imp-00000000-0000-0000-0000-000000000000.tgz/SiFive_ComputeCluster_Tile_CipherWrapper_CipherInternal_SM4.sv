//
// Copyright (c) 2016-2026 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
// Instance ID: 00000000-0000-0000-0000-000000000000, 35016b34-f1c6-4c19-890b-7f1ddda9d5a7

module SiFive_ComputeCluster_Tile_CipherWrapper_CipherInternal_SM4(
  input  [127:0] io_rksIn,
  input  [127:0] io_xsIn,
  input  [2:0]   io_rnd,
  input          io_isKE,
  output [127:0] io_rksOrXsOut
);

  wire [7:0][31:0] _GEN = '{32'h646B7279, 32'hF4FB0209, 32'h848B9299, 32'h141B2229, 32'hA4ABB2B9, 32'h343B4249, 32'hC4CBD2D9, 32'h545B6269};
  wire [7:0][31:0] _GEN_0 = '{32'h484F565D, 32'hD8DFE6ED, 32'h686F767D, 32'hF8FF060D, 32'h888F969D, 32'h181F262D, 32'hA8AFB6BD, 32'h383F464D};
  wire [7:0][31:0] _GEN_1 = '{32'h2C333A41, 32'hBCC3CAD1, 32'h4C535A61, 32'hDCE3EAF1, 32'h6C737A81, 32'hFC030A11, 32'h8C939AA1, 32'h1C232A31};
  wire [7:0][31:0] _GEN_2 = '{32'h10171E25, 32'hA0A7AEB5, 32'h30373E45, 32'hC0C7CED5, 32'h50575E65, 32'hE0E7EEF5, 32'h70777E85, 32'h70E15};
  (* keep = "true" *)
  wire [2:0]       _GEN_ARRAY_IDX = io_rnd;
  wire [31:0]      _GEN_3 = io_isKE ? io_rksIn[63:32] : 32'h0;
  wire [31:0]      _GEN_4 = io_isKE ? 32'h0 : io_xsIn[63:32];
  wire [31:0]      _GEN_5 = io_isKE ? io_rksIn[95:64] : 32'h0;
  wire [31:0]      _GEN_6 = io_isKE ? 32'h0 : io_xsIn[95:64];
  wire [31:0]      _GEN_7 = io_isKE ? io_rksIn[127:96] : 32'h0;
  wire [31:0]      _GEN_8 = io_isKE ? 32'h0 : io_xsIn[127:96];
  wire [31:0]      _GEN_9 = io_isKE ? _GEN_2[_GEN_ARRAY_IDX] : 32'h0;
  wire [31:0]      _GEN_10 = io_isKE ? 32'h0 : io_rksIn[31:0];
  wire [31:0]      _GEN_14;
  wire [31:0]      _GEN_5_0 = (_GEN_3 | _GEN_4) ^ (_GEN_5 | _GEN_6) ^ (_GEN_7 | _GEN_8) ^ (_GEN_9 | _GEN_10);
  wire [31:0]      _GEN_11 = io_rksIn[31:0] ^ _GEN_14 ^ {_GEN_14[18:0], _GEN_14[31:19]} ^ {_GEN_14[8:0], _GEN_14[31:9]};
  wire [31:0]      _GEN_12 =
    io_xsIn[31:0] ^ _GEN_14 ^ {_GEN_14[29:0], _GEN_14[31:30]} ^ {_GEN_14[21:0], _GEN_14[31:22]} ^ {_GEN_14[13:0], _GEN_14[31:14]}
    ^ {_GEN_14[7:0], _GEN_14[31:8]};
  (* keep = "true" *)
  wire [2:0]       _GEN_ARRAY_IDX_0 = io_rnd;
  wire [31:0]      _GEN_13 = io_isKE ? io_rksIn[95:64] : 32'h0;
  wire [31:0]      _GEN_15 = io_isKE ? 32'h0 : io_xsIn[95:64];
  wire [31:0]      _GEN_16 = io_isKE ? io_rksIn[127:96] : 32'h0;
  wire [31:0]      _GEN_17 = io_isKE ? 32'h0 : io_xsIn[127:96];
  wire [31:0]      _GEN_18 = io_isKE ? _GEN_11 : 32'h0;
  wire [31:0]      _GEN_19 = io_isKE ? 32'h0 : _GEN_12;
  wire [31:0]      _GEN_20 = io_isKE ? _GEN_1[_GEN_ARRAY_IDX_0] : 32'h0;
  wire [31:0]      _GEN_21 = io_isKE ? 32'h0 : io_rksIn[63:32];
  wire [31:0]      _GEN_10_0 = (_GEN_13 | _GEN_15) ^ (_GEN_16 | _GEN_17) ^ (_GEN_18 | _GEN_19) ^ (_GEN_20 | _GEN_21);
  wire [31:0]      _GEN_6_0;
  wire [31:0]      _GEN_22 = io_rksIn[63:32] ^ _GEN_6_0 ^ {_GEN_6_0[18:0], _GEN_6_0[31:19]} ^ {_GEN_6_0[8:0], _GEN_6_0[31:9]};
  wire [31:0]      _GEN_23 =
    io_xsIn[63:32] ^ _GEN_6_0 ^ {_GEN_6_0[29:0], _GEN_6_0[31:30]} ^ {_GEN_6_0[21:0], _GEN_6_0[31:22]} ^ {_GEN_6_0[13:0], _GEN_6_0[31:14]}
    ^ {_GEN_6_0[7:0], _GEN_6_0[31:8]};
  (* keep = "true" *)
  wire [2:0]       _GEN_ARRAY_IDX_1 = io_rnd;
  wire [31:0]      _GEN_13_0 = io_rksIn[127:96] ^ _GEN_11 ^ _GEN_22 ^ _GEN_0[_GEN_ARRAY_IDX_1];
  wire [31:0]      _GEN_4_0;
  wire [31:0]      _GEN_1_0 = io_xsIn[127:96] ^ _GEN_12 ^ _GEN_23 ^ io_rksIn[95:64];
  wire [31:0]      _GEN_24 = io_rksIn[95:64] ^ _GEN_4_0 ^ {_GEN_4_0[18:0], _GEN_4_0[31:19]} ^ {_GEN_4_0[8:0], _GEN_4_0[31:9]};
  wire [31:0]      _GEN_12_0;
  wire [31:0]      _GEN_25 =
    io_xsIn[95:64] ^ _GEN_12_0 ^ {_GEN_12_0[29:0], _GEN_12_0[31:30]} ^ {_GEN_12_0[21:0], _GEN_12_0[31:22]} ^ {_GEN_12_0[13:0], _GEN_12_0[31:14]}
    ^ {_GEN_12_0[7:0], _GEN_12_0[31:8]};
  (* keep = "true" *)
  wire [2:0]       _GEN_ARRAY_IDX_2 = io_rnd;
  wire [31:0]      _GEN_26 = io_isKE ? _GEN_11 : 32'h0;
  wire [31:0]      _GEN_27 = io_isKE ? 32'h0 : _GEN_12;
  wire [31:0]      _GEN_28 = io_isKE ? _GEN_22 : 32'h0;
  wire [31:0]      _GEN_29 = io_isKE ? 32'h0 : _GEN_23;
  wire [31:0]      _GEN_30 = io_isKE ? _GEN_24 : 32'h0;
  wire [31:0]      _GEN_31 = io_isKE ? 32'h0 : _GEN_25;
  wire [31:0]      _GEN_32 = io_isKE ? _GEN[_GEN_ARRAY_IDX_2] : 32'h0;
  wire [31:0]      _GEN_33 = io_isKE ? 32'h0 : io_rksIn[127:96];
  wire [31:0]      _GEN_3_0 = (_GEN_26 | _GEN_27) ^ (_GEN_28 | _GEN_29) ^ (_GEN_30 | _GEN_31) ^ (_GEN_32 | _GEN_33);
  wire [31:0]      _GEN_0_0;
  wire [31:0]      _GEN_34 =
    io_xsIn[127:96] ^ _GEN_0_0 ^ {_GEN_0_0[29:0], _GEN_0_0[31:30]} ^ {_GEN_0_0[21:0], _GEN_0_0[31:22]} ^ {_GEN_0_0[13:0], _GEN_0_0[31:14]}
    ^ {_GEN_0_0[7:0], _GEN_0_0[31:8]};
  wire [31:0]      _GEN_35 = io_isKE ? io_rksIn[127:96] ^ _GEN_0_0 ^ {_GEN_0_0[18:0], _GEN_0_0[31:19]} ^ {_GEN_0_0[8:0], _GEN_0_0[31:9]} : 32'h0;
  wire [31:0]      _GEN_36 = io_isKE ? 32'h0 : _GEN_34;
  wire [31:0]      _GEN_37 = io_isKE ? _GEN_24 : 32'h0;
  wire [31:0]      _GEN_38 = io_isKE ? 32'h0 : _GEN_25;
  wire [31:0]      _GEN_39 = io_isKE ? _GEN_22 : 32'h0;
  wire [31:0]      _GEN_40 = io_isKE ? 32'h0 : _GEN_23;
  wire [31:0]      _GEN_41 = io_isKE ? _GEN_11 : 32'h0;
  wire [31:0]      _GEN_42 = io_isKE ? 32'h0 : _GEN_12;
  SiFive_ComputeCluster_Tile_CipherWrapper_CipherInternal_CipherInternal_SM4SBoxLUT round_5_S1_sBoxRes_sBoxLUT (
    .io_in  (_GEN_10_0),
    .io_out (_GEN_6_0)
  );
  SiFive_ComputeCluster_Tile_CipherWrapper_CipherInternal_CipherInternal_SM4SBoxLUT round_7_S3_sBoxRes_sBoxLUT (
    .io_in  (_GEN_3_0),
    .io_out (_GEN_0_0)
  );
  SiFive_ComputeCluster_Tile_CipherWrapper_CipherInternal_CipherInternal_SM4SBoxLUT round_4_sBoxRes_sBoxLUT (
    .io_in  (_GEN_5_0),
    .io_out (_GEN_14)
  );
  SiFive_ComputeCluster_Tile_CipherWrapper_CipherInternal_CipherInternal_SM4SBoxLUT round_6_S2_sBoxLUT_1 (
    .io_in  (_GEN_1_0),
    .io_out (_GEN_12_0)
  );
  SiFive_ComputeCluster_Tile_CipherWrapper_CipherInternal_CipherInternal_SM4SBoxLUT round_6_S2_sBoxLUT (
    .io_in  (_GEN_13_0),
    .io_out (_GEN_4_0)
  );
  assign io_rksOrXsOut = {_GEN_35 | _GEN_36, _GEN_37 | _GEN_38, _GEN_39 | _GEN_40, _GEN_41 | _GEN_42};
endmodule

